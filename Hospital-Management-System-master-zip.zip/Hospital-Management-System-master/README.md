# Hospital-Management-System
Java mini project Hospital Management System with SQL database.
To run this properly use wampserver or any other sql server and create table and database according to project code or modify code accordings to your database & table name.

